from django.apps import AppConfig


class PublisherAppConfig(AppConfig):
    name = 'publisher_app'
